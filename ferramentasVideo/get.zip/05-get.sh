#!/bin/bash

# Define o nome do arquivo Python e do serviço
NOME_SCRIPT="05-get.py"
NOME_SERVICO="capturador.service"

# Pega o caminho absoluto da pasta onde este script .sh está sendo executado
DIRETORIO_ATUAL=$(pwd)
CAMINHO_SCRIPT="$DIRETORIO_ATUAL/$NOME_SCRIPT"

# Verifica se o get.py realmente existe nesta pasta
if [ ! -f "$CAMINHO_SCRIPT" ]; then
    echo "Erro: O arquivo $NOME_SCRIPT não foi encontrado na pasta atual ($DIRETORIO_ATUAL)."
    echo "Por favor, coloque este script .sh na mesma pasta que o $NOME_SCRIPT e tente novamente."
    exit 1
fi

echo "Criando o serviço systemd para: $CAMINHO_SCRIPT"

# Cria a pasta de serviços do usuário caso não exista
PASTA_SYSTEMD="$HOME/.config/systemd/user"
mkdir -p "$PASTA_SYSTEMD"

# Cria o arquivo .service com as configurações adequadas
cat <<EOF > "$PASTA_SYSTEMD/$NOME_SERVICO"
[Unit]
Description=Serviço Get.py de Captura de Tela
After=graphical-session.target

[Service]
ExecStart=/usr/bin/python3 $CAMINHO_SCRIPT
Restart=on-failure
Environment="DISPLAY=:0"
Environment="XAUTHORITY=%h/.Xauthority"

[Install]
WantedBy=default.target
EOF

echo "Arquivo de serviço criado em: $PASTA_SYSTEMD/$NOME_SERVICO"

# Recarrega o systemd, habilita no boot e inicia o serviço
echo "Configurando o systemctl..."
systemctl --user daemon-reload
systemctl --user enable "$NOME_SERVICO"
systemctl --user restart "$NOME_SERVICO"

echo ""
echo "===================================================="
echo "✅ Instalação concluída com sucesso!"
echo "O serviço '$NOME_SERVICO' está rodando e iniciará com o sistema."
echo "Para ver o status a qualquer momento, digite:"
echo "systemctl --user status $NOME_SERVICO"
echo "===================================================="
